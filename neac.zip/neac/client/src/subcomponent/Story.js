import React from "react";

const Story = () => {
  return (
    <div className="container-fluid p-0">
      {/* Hero Section */}
      <div className="position-relative text-white text-center bg-dark py-5" style={{ backgroundImage: "url('/hero-image.jpg')", backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <div className="overlay" style={{ background: "rgba(0, 0, 0, 0.6)", position: "absolute", top: 0, left: 0, width: "100%", height: "100%" }}></div>
        <h1 className="position-relative fw-bold">Preserving Heritage Through Digital Innovation 🏺</h1>
        <p className="position-relative">Connecting Northeast Indian Artisans with Global Markets</p>
      </div>

      {/* Vision & Mission */}
      <div className="container py-5">
        <div className="row text-center">
          <div className="col-md-6">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h3>🎯 Our Vision</h3>
              <p>Empower Northeast Indian artisans by connecting traditional crafts to global markets. We aim to preserve cultural heritage while ensuring economic sustainability for artisans.</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h3>🚀 Our Mission</h3>
              <p>Bridge cultural heritage with a modern digital marketplace, providing fair opportunities and recognition to skilled craftsmen.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="container pb-5">
        <div className="row text-center">
          <div className="col-md-3">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h4>Support Artisans</h4>
              <p>Authentic storytelling to maximize exposure and economic opportunities.</p>
            </div>
          </div>
          <div className="col-md-3">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h4>Accessibility</h4>
              <p>Multilingual user-friendly e-commerce platform for global reach.</p>
            </div>
          </div>
          <div className="col-md-3">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h4>Global Demand</h4>
              <p>Market products to a global audience with seamless transactions.</p>
            </div>
          </div>
          <div className="col-md-3">
            <div className="p-3 border rounded shadow-sm bg-light">
              <h4>Regional Categories</h4>
              <p>Curated by region to highlight diverse artisan techniques.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Platform Features */}
      <div className="container py-5 text-center bg-danger text-white">
        <h2>Platform Features</h2>
        <div className="row">
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>📱 Mobile Optimized</p>
              <p>Responsive experience for all devices.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>💳 Payment Integration</p>
              <p>Secure and seamless transaction options.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>📢 Social Sharing</p>
              <p>Share artisan stories and products easily.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>⭐ Ratings & Reviews</p>
              <p>Build trust and engagement through feedback.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>🚚 Order Tracking</p>
              <p>Real-time updates on purchases.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>🎨 Custom Orders</p>
              <p>Personalized handcrafted products.</p>
            </div>
          </div>
          <div className="col-md-3 my-2">
            <div className="p-3 border rounded bg-light text-dark">
              <p>💬 Live Chat Support</p>
              <p>Instant assistance for buyers and sellers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Story;
