import React from "react";

const ContactUs = () => {
  return (
    <div>
      {/* Header Section */}
      <div className="bg-dark text-white text-center py-5 shadow-sm">
        <h1 className="fw-bold display-5">Get in Touch</h1>
        <p className="lead">We'd love to hear from you! Whether you have questions, feedback, or collaboration ideas, reach out to us.</p>
      </div>

      {/* Contact Form & Info */}
      <div className="container mt-5">
        <div className="row d-flex justify-content-center">
          <div className="col-md-6 p-4 bg-light rounded-3 shadow-sm">
            <h3 className="fw-bold text-danger text-center">Contact Us</h3>
            <p className="text-muted text-center">Fill out the form below, and we'll get back to you as soon as possible.</p>
            <form>
              <div className="mb-3">
                <label className="form-label">Full Name</label>
                <input type="text" className="form-control" placeholder="Enter your full name" required />
              </div>
              <div className="mb-3">
                <label className="form-label">Email Address</label>
                <input type="email" className="form-control" placeholder="Enter your email" required />
              </div>
              <div className="mb-3">
                <label className="form-label">Phone Number</label>
                <input type="tel" className="form-control" placeholder="Enter your phone number" required />
              </div>
              <div className="mb-3">
                <label className="form-label">Message</label>
                <textarea className="form-control" rows="5" placeholder="Write your message here..." required></textarea>
              </div>
              <div className="text-center">
                <button type="submit" className="btn btn-danger">Send Message</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Additional Contact Info */}
      <div className="container mt-5 text-center">
        <div className="row">
          <div className="col-md-4 p-3">
            <h5 className="fw-bold">📍 Our Address</h5>
            <p>123 Artisan Street, Guwahati, Assam, India</p>
          </div>
          <div className="col-md-4 p-3">
            <h5 className="fw-bold">📞 Call Us</h5>
            <p>+91 98765 43210 (Available 9 AM - 6 PM IST)</p>
          </div>
          <div className="col-md-4 p-3">
            <h5 className="fw-bold">✉️ Email Us</h5>
            <p>support@artisansNE.com</p>
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default ContactUs;