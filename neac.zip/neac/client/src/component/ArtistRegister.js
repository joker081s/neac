import React, { useState } from "react";
import { useAuthContext } from "../context/AuthContext";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ArtistRegister = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    location: "",
    bio: "",
    password: "",
    image: null,
  });

  const [error, setError] = useState("");
  const { toastfn, errortoastfn } = useAuthContext();
  const navigate = useNavigate();

  const handleChange = (e) => {
    if (e.target.name === "image") {
      setFormData({ ...formData, image: e.target.files[0] });
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, email, location, bio, password, image } = formData;

    if (!name || !email || !location || !bio || !password || !image) {
      setError("All fields are required.");
      return;
    }

    const formDataToSend = new FormData();
    formDataToSend.append("name", name);
    formDataToSend.append("email", email);
    formDataToSend.append("location", location);
    formDataToSend.append("bio", bio);
    formDataToSend.append("password", password);
    formDataToSend.append("image", image);

    try {
      const res = await axios.post(
        "http://localhost:8080/api/user/signupartist",
        formDataToSend,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      if (res?.data?.success) {
        toastfn("Signed up successfully");
        navigate("/signin");
      } else {
        errortoastfn(res?.data?.message || "Signup failed");
      }
    } catch (error) {
      console.error(error);
      errortoastfn("Some internal error has occurred. Please try again later.");
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-md-center">
        <div className="col-md-6">
          <h2 className="text-center mb-4">Artist Registration</h2>

          {error && <div className="alert alert-danger">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Name</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter your name"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-control"
                placeholder="Enter your email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Location</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter your location"
                name="location"
                value={formData.location}
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Bio</label>
              <textarea
                className="form-control"
                rows="3"
                placeholder="Tell us about yourself"
                name="bio"
                value={formData.bio}
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                placeholder="Enter your password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Profile Image</label>
              <input
                type="file"
                className="form-control"
                name="image"
                accept="image/*"
                onChange={handleChange}
              />
            </div>

            <button type="submit" className="btn btn-danger w-100">
              Register
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ArtistRegister;
