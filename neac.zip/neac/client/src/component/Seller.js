import data from "../data.js"; // Importing the JSON data

const Seller = () => {
  return (
    <div className="container">
      <h2 className="text-center my-4">Featured Artists</h2>
      <div className="row">
        {data.map((artist) => (
          <div key={artist.id} className="col-md-4 mb-2"  style={{"height" : "30rem"}} >
            <div className="card p-1 shadow-sm" style={{"height" : "100%"}}>
              <img src={artist.profileImage} style={{ "margin" : "auto" , "width":"95%" , "height":"60%"}} className="card-img-top" alt={artist.name} />
              <div className="card-body text-center">
                <h5 className="card-title">{artist.name}</h5>
                <p className="text-muted">{artist.region}</p>
                <p className="card-text">{artist.bio}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Seller;
