import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import '../style/detail.css'
import { FaArrowRight ,FaPlus , FaMinus} from "react-icons/fa";
import { MdOutlineStar } from "react-icons/md";
import FoodCard from '../subcomponent/FoodCard';
import { useCartContext } from '../context/CartContentext';
import { useAuthContext } from '../context/AuthContext';
// import {addItm} from '../context/CartContentext'

const DetailedFood = () => {
  const {isAuthorized , CheckAuthentication ,toastfn , errortoastfn} = useAuthContext();
  
  
    const {id} = useParams();
    const [fooditm , setItm] = useState();
    const [count , setCount] = useState(1);
    const[price , setPrice] = useState(0);
    const [pricetyp , setPriceTyp] = useState()
    const [Similar , setSimilar] = useState([]);
    const {addItm} = useCartContext();
    const navigate= useNavigate();
    // console.log(price);
    // console.log(fooditm);

    // var result = [];
    // if(fooditm){
    //  result =  Object.keys(fooditm.options[0]).map((key) => [key, fooditm.options[0][key]]);
    // }
    // console.log(result);

    // function to fetch the seleted food itm's complete details details 
    const details = async()=>{
      try {
        if(id){
          const res = await axios.get(`http://localhost:8080/api/food/getsingleFood/${id}`);
          // console.log(res);
          if(res?.data?.success){
            setItm(res.data.foodData[0]);
            setPrice(fooditm.price);
          }
        }
      } catch (error) {
        console.log(error);
        // errortoastfn("something went wrong please try again later")
      }
    }


    const increment=()=>{
      if(count < 10){
        setCount(count+1);
        setPrice(count*fooditm.price);
      }
      else{
        setCount(1);
        setPrice(count*fooditm.price);
      }
    }
    const decrement=()=>{
      if(count > 1){
        setCount(count-1);
        setPrice(count*fooditm.price);
      }
      else{
        setCount(1);
        setPrice(count*fooditm.price);
      }
    }


    const handleSubmit = (e)=>{
      e.preventDefault();
      setPrice(count*fooditm.price);
      if(!price){
        errortoastfn("Select the price");
        return;
      }

      const cartitm = {
        price : price,
        name : fooditm.name,
        img : fooditm.image,
        qty : count,
        id : fooditm._id,
        subtotal : count * price
      }
      console.log(cartitm);
      addItm(cartitm);
      navigate('/cart');
      
    }

    const getthedata =async()=>{
      try {
          if(fooditm?.category){
              const res = await axios.get(`http://localhost:8080/api/food/foodofsinglesamecat/${fooditm.category}`);
              // console.log(res);
              if(res?.data?.success){
                  setSimilar(res.data.data);
              }
          }
      } catch (error) {
          console.log(error);
          // errortoastfn("something went wrong , Please try again later.")
      }
  }

  let path = useLocation().pathname;
    useEffect(()=>{
        // if(!isAuthorized){
        //   CheckAuthentication(path);
        // }else{
          details();
        // }
 
    },[]);
    useEffect(()=>{
      getthedata()
    } , [fooditm]);
  return (
    <div className='container' style={{'minHeight' : "22rem"}}>
      {fooditm ? <div className="row mt-5">
            <div className="col-md-5 dimg"> <img src={fooditm.image} alt="" /> </div>
            <div className="col-md-7">
              <h2 className='text-center' style={{'textDecoration' : "underline red 4px"}}> {fooditm.artist} </h2>
              <p className='text-center dtxt text-secondary mt-2'>  {fooditm.name} {<FaArrowRight />} {fooditm.category} {<FaArrowRight/>} Ratings <span class="badge bg-danger">{fooditm.rating} <MdOutlineStar className='mb-1'/> </span></p>

              <p className='text-secondary'> <span style={{'textDecoration' : "underline red 2px" , 'color' : "black" , 'fontWeight' : "bold"}}>Description </span> : {fooditm.info} </p>

              <div className="row d-flex flex-row justify-content-around">
                
                <div className="col-sm-3 border dqntity d-flex justify-content-center align-items-center"> <FaMinus className='text-secondary' onClick={ decrement } /> <p className='mt-3 mx-2'> {count} </p> <FaPlus className='text-secondary' onClick={ increment } /> </div>
                <div className=" col-sm-4 border dtotal text-center d-flex justify-content-center align-items-center "> Total : Rs {fooditm.price * count} </div>
              </div>

              <div className='d-flex justify-content-center mt-4'>
               <button className=' btn btn-success'  onClick={handleSubmit}> Add to Cart </button>
              </div>

            </div>
            <div className="col-12 mt-3">
              <h2> <span className='text-danger'>Similar </span> Interest </h2>
              <div className="row">
              { Similar.length ? Similar.map((itm , indx)=> <FoodCard key={indx} food = {itm} />)  : ""}
              { Similar.length ? Similar.map((itm , indx)=> <FoodCard key={indx} food = {itm} />)  : ""}
              </div>
            </div>
        </div> : ""}
        
      
    </div>
  )
}

export default DetailedFood
